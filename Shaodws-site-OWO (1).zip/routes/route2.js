const express = require('express');

const router = express.Router();
let othc = new OAuthClient('765578525818093608', 'CXJVX5fQHU5xKOc5RWTbl3mytIEDjgvQ');
othc.setScopes(['guilds', 'identify'])
othc.setRedirect('https://Shaodws-site-OWO.nongmerbot.repl.co/login')
router.get('/login', async (req, res) => {
    let code = req.query.code;
    if (code == undefined)
    res.json({ status: 401, error: "no auth code found?"})
    else {
      let userkey  await  othc.getAccess(code);
       res.cookies.set('key', userkey);
  
       res.redirect('/user/')
    }
})
router.get('/user/', async (req, res) => {
    let key = req.cookies.get('key');
    if(key) {
let user = await othc.getAuthorizedUser(key);
res.render('user', {
   name:  user.username,
   id: user.id
})
    }
})
module.exports = router;