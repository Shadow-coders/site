module.exports = (app, client) => {
	const fs = require('fs');
	const logger = require("./logger.js");
	const folders = fs.readdirSync(__dirname + '/endpoints');

	for (const files of folders) {
		const folder = fs
			.readdirSync(`${__dirname}/endpoints/${files}/`)
			.filter(file => file.endsWith('.js'));

		for (const endpoints of folder) {
			const endpoint = require(`${__dirname}/endpoints/${files}/${endpoints}`);

			let type = endpoint.type || 'get';

			if (!endpoint.name)
				return console.log("There's an Endpoint with no Name.");
			let ePoint = endpoint.name;
			let ePApi = ePoint
				.replace('/api/', '')
				.replace('/', ' | ')
				.replace('-', ' ');
      logger("used", client, ePApi)
			app[type](endpoint.name, async (req, res) => {
				endpoint.run(req, res);
			});
			console.log(`Loaded the ${endpoint.name} Endpoint...`);
		}
	}
};
