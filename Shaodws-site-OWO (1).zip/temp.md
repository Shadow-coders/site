# Shadow 
**what is shadow?**
Shadow is a bot simeler to [xela](https://xela.dev)
 but not encluding economy! and its not limited to certin people plus No premium
