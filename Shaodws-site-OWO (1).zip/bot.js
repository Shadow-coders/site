module.exports = async (client, app) => {
const config = require("./config.js");
const Discord = require("discord.js");
client.on('ready', () => {
    console.log(`Bot Ready!
Logged in as ${client.user.tag}`);
    const status = ``;
    const statustype = "PLAYING";
    const url = "none"
    client.user.setActivity(`${client.ws.ping} || ${client.user.tag}`, { type: `${statustype}`})
    .then(presence => console.log(`Activity set to ${presence.activities[0].type}: ${presence.activities[0].name}`))
    .catch(console.error);
});



// after 5 seconds stop
// setTimeout(() => { clearInterval(timerId); alert('stop'); }, 5000);
client.on('messageDelete', message => {
	console.log(`A message by ${message.author.tag} was deleted, but we don't know by who yet. but we do know the content! ${message.content}`);
});

const ownerid = "566766267046821888"
client.on('message', message => {
	if (message.content) {
      if (message.channel.id === "825826344931819520") {
          message.delete();
      } else {
        console.log(message.author.tag + ' | ' + message.content)
      }
    } 
    if (message.content == "<@!784919808469762108>") {
        message.channel.send(` Hello ${message.author.nickname} i am <@${client.user.id}> and my prefix is \`$\`!`)
    }
    if (
		!message.content.startsWith(config.bot.prefix) ||
		message.author.bot ||
		!message.guild
	)
		return;

	const args = message.content
		.slice(config.bot.prefix.length)
		.trim()
		.split(' ');
	const command = args.shift().toLowerCase();
    
	 if (command === 'ping') {
        message.channel.send(`> **Ping:** ${Date.now() - message.createdTimestamp}ms
> **API Latency:** ${Math.round(client.ws.ping)}ms`);
    }
    // repeat with the interval of 2 seconds
    let userr = client.users.fetch('765578525818093608');
function check() {
console.log('aaaaaa');
}





// program to display a text using setInterval method

// let timerId = setInterval(() => {let user = client.users.fetch('765578525818093608');
//  if(user.presence.status === "offline") {
//       console.log('what')
//       }
//        if (user.presence.status === "idle")
//        { console.log('idle')
//        }
//         else { console.log('yaaaaa')}
// }), 2000);


    if (command === "help") {
     let embed = new Discord.MessageEmbed()
     .setTitle("Commands")
     .setColor("BLUE")
     .setDescription("`_ping` - all we hev.lol")
    .setFooter(`Ping: ${client.ws.ping}`)
        
        return message.channel.send(embed)
    }
     if (command === 'bot'){
        
        const botEmbed = new Discord.MessageEmbed()
            .setColor('#2f3136')
            .setTitle(`${client.user.tag}`)
            .addField('Status', `${client.user.presence.status}`, true)
            .addField('Bot Owner', `<@${ownerid}>`, true)
            .addField('Bot ID', `${client.user.id}`, true)
            .addField('Total Guilds', `${client.guilds.cache.size}`, true)
            .addField('Total Users', `${client.users.cache.size}`, true)
            .addField('Total Channels', `${client.channels.cache.size}`, true)
            .addField('Created At', `${client.user.createdAt}`)
            .setFooter(`©️ ${client.user.username}`)
        message.channel.send(botEmbed);
        
    }
     if (command === 'server') {
        
        const serverEmbed = new Discord.MessageEmbed()
            .setColor('#0098ff')
            .setTitle(`${message.guild.name}`)
            .setThumbnail(`https://cdn.discordapp.com/icons/${message.guild.id}/${message.guild.icon}`)
            .addField('👥 Total Members', `${message.guild.memberCount}`, true)
            .addField('🆔 ID', `${message.guild.id}`, true)
            .addField('👑 Owner', `${message.guild.owner}`, true)
            .addField(`💠 Boost level (${message.guild.premiumTier})`, `${message.guild.premiumSubscriptionCount}`, true)
            .addField('🗒️ Roles Count', `${message.guild.roles.cache.size}`, true)
            .addField('✨ Emoji Count', `${message.guild.emojis.cache.size}`, true)
            .addField('🛡️ Verification Level', `${message.guild.verificationLevel}`, true)
            .addField('💤 AFK Channel', `${message.guild.afkChannel}`, true)
            .addField('🌐 Region', `${message.guild.region}`, true)
        message.channel.send(serverEmbed);
        
    }
     if (command === 'user') {
    
        const user = message.mentions.users.first() || message.author;
        const userEmbed = new Discord.MessageEmbed()
            .setColor('#0098ff')
            .setTitle(`${user.tag}`)
            .setThumbnail(`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}`)
            .addField('🆔 ID', `${user.id}`, true)
            .addField('Bot', `${user.bot}`, true)
            .addField('Status', `${user.presence.status}`, true)
            .addField('Created At', `${user.createdAt}`)
        message.channel.send(userEmbed);
        
    }
    if (command == 'avatar') {
        
        const user = message.mentions.users.first() || message.author;
        const avatarEmbed = new Discord.MessageEmbed()
            .setColor('#2f3136')
            .setTitle(`${user.username}'s Avatar`)
            .setURL(user.avatarURL({ dynamic: true, size: 1024}))
            .setImage(user.avatarURL({ dynamic: true, size: 1024}))
        message.channel.send(avatarEmbed);
        
    } 
    if (command === "status") {
       
        const status = ``;
    const statustype = "PLAYING";
    const url = "none"
        client.user.setActivity(`${client.ws.ping} || ${client.user.tag}`, { type: `${statustype}`})
    .then(presence => message.channel.send(`Activity set to ${presence.activities[0].type}: ${presence.activities[0].name}`))
    .catch(console.error);
   
    } if (command === "api-key") {
        const Caxinha = require("caxinha");
        let result = Caxinha.randomCharacters(40)
        const embed = new Discord.MessageEmbed()
        .setTitle('api key')
        .setDescription(`\`\`\`
        ${result}
        \`\`\``)
        .setFooter('keep this safe!')
        message.author.send(embed).catch(e => message.channel.send('faild to dm you make sure you open ur dms!'))
        message.channel.send('Check your dms!')
        const db = require('quick.db')
        db.set('api-keys', db.get('api-keys') + result)

    } if(command === "eval") {
        if (message.author.id === "566766267046821888") {
           try{
            const db = require('quick.db')
            const str1 = message.content.replace('$eval ', '')
            const str2 = `${str1}`
eval(str2)
           } catch (e) {
               return message.channel.send('error: \n' + '```' + e + '```')
           }
        } else {
            message.channel.send(':star: you tried')
        }
    }
 


    });

    app.get('/vid', (req, res) => {
    res.render('test')
})

async function greet() {
    let user = await client.users.fetch
    ('765578525818093608');
    const { Webhook, MessageBuilder } = require('discord-webhook-node');
const hook = new Webhook('https://discord.com/api/webhooks/812447456649543750/rgISPj1m9l3RugSNSYpnElLSQZpWczQWx66p_lBS0EraaloFOKuY_uUFfDu9AmMz8ATy');
    const db = require('quick.db')
//

function checkStatus(res, message) {
    if (res.ok) { // res.status >= 200 && res.status < 300
        return res;
    } else {
        const embed_check = new Discord.MessageEmbed()
.setTitle('Status')
.setColor('#ff0000')
.setDescription(`
PANEL is down!
url: \\*\\*\\*\\*\\*\\*\\*\\*.tk <-- hidden
status code:  ${res.statuscode}

`)
        client.channels.fetch('832694631459192903').then((channel, msg)=> { channel.send(embed_check) })
    }
}
 const fetch = require('node-fetch')
fetch('https://panel.nexusnodes.tk/')
    .then(checkStatus(res))
    .then(res => {})
 if(user.presence.status === "offline") {
       if(db.get('said-off') === false) {
            console.log(`${user.tag} is offline bruh`)
       client.channels.cache.get('765669027552559149').send(`${user.tag} is offline bruh`) 
        db.set('said-off', true)
        } else {
            return console.log('ok its something else');
        }
      }
       if (user.presence.status === "online")
       { 
        
            if(db.get('said-online') === false)  {
            console.log(`${user.tag} is online bruh`)
        // hook.send(`${user.tag} is online bruh`)
         client.channels.cache.get('765669027552559149').send(`${user.tag} is online! `)
        db.set('said-online', true)
        } else {
            return;
        }
       }
        else {
            return console.log('ok else');
        }
}

// setInterval(greet, 1000);
        
} 
// db0a5c97-af67-4ed9-884e-98a00c302704.repl.co