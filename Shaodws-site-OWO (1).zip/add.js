const fetech = require(`node-fetch`);//p
const { Database } = require("quickmongo");
const db = new Database("mongodb+srv://Shadow:JPybih5LjcL3FnX8@cluster0.guaej.mongodb.net/Cluster0?retryWrites=true&w=majority", 'sites');
//p
const config = require(`./config`)
const TOKEN = "NzY1NTc4NTI1ODE4MDkzNjA4.X4W2kA.qNAMkUmbNMjCrXXDa38BsabT7z8";
async function adduser() {
    const fetech = require(`node-fetch`);
const user = await db.get('user')
    const response = await fetech(`https://discord.com/api/v8/guilds/778350378445832233/members/${user.id}
`, {
    method: 'PUT',
    headers: {
        Authorization: `Bot ${TOKEN}`,
        "Content-type":'application/json'
    },   
    body: JSON.stringify({ access_token: user.accessToken })
});
return response.json();
}
module.exports = ( adduser() )