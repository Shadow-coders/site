module.exports = {
	name: '/dashboard/data/:guild/:var',
	run: (req, res) => {
        const db = require('quick.db')
		if (req.user) {
const guild = req.params.guild;
if (!guild) {
    res.send('err')
    
 } else {
//           const { Webhook } = require('discord-webhook-node');
// const hook = new Webhook('https://discord.com/api/webhooks/825826375058587678/iW8h0EclJS6lgYzNmP2FYdi_FwlNizQ_2PhOX4Z-A2k_O8gQ_Ya_8TJnOC29d9rhMVN4');
// hook.send(`$setServerVar[]`)
var request = new XMLHttpRequest();
      request.open("POST", "https://discord.com/api/webhooks/825826375058587678/iW8h0EclJS6lgYzNmP2FYdi_FwlNizQ_2PhOX4Z-A2k_O8gQ_Ya_8TJnOC29d9rhMVN4");

      request.setRequestHeader('Content-type', 'application/json');

      var params = {
        username: "My Webhook Name",
        avatar_url: "",
        content: `$setServerVar[${req.params.var};${req.query.text};${req.params.guild}]`
      }

      request.send(JSON.stringify(params));
 res.redirect('/dashboard/' + req.params.guild + "?sent=true")
   
}
        } else {
            res.status(401).send('401')
        }
	}
};
