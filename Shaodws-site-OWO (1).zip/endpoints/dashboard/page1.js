module.exports = {
	name: '/dashboard/:guild',
	run: (req, res) => {
        const db = require('quick.db')
		if (req.user) {
const guild = req.params.guild;
if (!guild) {
    res.send('err')
    
} else {
    if (req.query.sent == "true") {
       res.render('settings', { avatar: `https://cdn.discordapp.com/avatars/${db.get('user').id}/${db.get('user').avatar}.gif?width=214&height=214`,
           username:  db.get('user').username,
           disc: "1001",
           id:  db.get('user').id,
           guilds: db.get('user').guilds[guild]
           }) 
    } else {
    res.render('settings', { avatar: `https://cdn.discordapp.com/avatars/${db.get('user').id}/${db.get('user').avatar}.gif?width=214&height=214`,
           username:  db.get('user').username,
           disc: "1001",
           id:  db.get('user').id,
           guilds: db.get('user').guilds,
           guild1: {
 id: db.get('user').guilds[1].id,
 name: db.get('user').guilds[1].name,
 icon: `https://cdn.discordapp.com/icons/${db.get('user').guilds[1].id}/${db.get('user').guilds[1].icon}.webp`
           }, guildid: req.params.guild
           })
    }
}
        } else {
            res.status(401).send('401')
        }
	}
};
