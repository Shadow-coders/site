module.exports = {
	name: '/api|chatbot',
	run: (req, res) => {
	const db = require('quick.db')
    const canvacord = require("canvacord");
    const str1 = db.get('api-keys')
    const str2 = JSON.stringify(str1)
    console.log(str2)
if (str2.includes(req.query.auth) == true) {
	const message = req.query.message || req.query.msg ||res.send('missing ?message=')
    const owner = req.query.dev || req.query.owner || "NeonGamerBot_QK";
    const user = req.query.user || res.send('missing ?user=')
    const bot = req.query.bot || req.query.api || "Shadow bot";
    const fetch = require('node-fetch');
    fetch(`https://api.affiliateplus.xyz/api/chatbot?message=${message}&botname=${bot}&ownername=${owner}&user=1`)
    .then(res => res.json())
    .then(json => {
        const str = json.message;
        const str2 = `${str}`;
        const msg = str2.replace('user', user)
        res.json({message: msg})
    });
    } else {
        res.send("no api key found... do ?auth for so")
    }
    } 
};
