module.exports = {
	name: '/api|sad-dude',
	run: (req, res) => {
	const axios = require('axios')
    const db = require('quick.db')
    const canvacord = require("canvacord");
    const str1 = db.get('api-keys')
    const str2 = JSON.stringify(str1)
    console.log(str2)
if (str2.includes(req.query.auth) == true) {
	const img = req.query.img || req.query.image || req.query.avatar || res.send('missing ?img=link')
    res.json({ link: `https://dinosaur.ml/overlay/goodbye/?image=${img}`, status: 200 })
    } else {
        res.send("no api key found... do ?auth for so")
    }
    } 
};
