module.exports = {
	name: '/api|spotify',
	run: (req, res) => {
	const db = require('quick.db')
    const canvacord = require("canvacord");
    const str1 = db.get('api-keys')
    const str2 = JSON.stringify(str1)
    console.log(str2)
if (str2.includes(req.query.auth) == true) {
const image = req.query.background ||  "https://is5-ssl.mzstatic.com/image/thumb/Features111/v4/a4/89/a1/a489a1cb-4543-6861-a276-4470d41d6a90/mzl.zcdmhnlk.jpg/800x800bb.jpeg";
const author = req.query.author || res.send('Missing ?author=')
const album = req.query.album || ""
const start = req.query.start || res.send('Missing ?start=<time>')
const end = req.query.end || res.send('Missing ?end=<time>')
const title = req.query.title || res.send('missing ?title=')
const card = new canvacord.Spotify()
    .setAuthor(author)
    .setStartTimestamp(start)
    .setEndTimestamp(end)
    .setImage(image)
    .setTitle(title);

card.build()
    .then(buffer => {
       res.set("Content-Type", "image/png")
        res.send(buffer)
    });
	} else {
        res.send("no api key found... do ?auth for so")
    }
    } 
};
