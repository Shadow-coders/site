const data = ['help', 'me', 'repl']
data.