module.exports = { 
    port: "8001",
    ip: "https://Shaodws-site-OWO.nongmerbot.repl.co",
    url: `https://`,
    webhook: "https://discord.com/api/webhooks/812447456649543750/rgISPj1m9l3RugSNSYpnElLSQZpWczQWx66p_lBS0EraaloFOKuY_uUFfDu9AmMz8ATy",
    auth: "CODE",
    bot: {
        token: "Nzg0OTE5ODA4NDY5NzYyMTA4.X8wTiQ.7DiC2q7lHxl7N2iKwOD3OqWn8lc",
        prefix: "$",
    },
    key: "12345",
    token: "NzY1NTc4NTI1ODE4MDkzNjA4.X4W2kA.qNAMkUmbNMjCrXXDa38BsabT7z8",
    monguri: "mongodb+srv://Shadow:JPybih5LjcL3FnX8@cluster0.guaej.mongodb.net/Cluster0?retryWrites=true&w=majority"
}