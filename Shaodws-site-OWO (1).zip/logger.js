module.exports = async (typ, client, endpoint, user) => {
  const Discord = require("discord.js")
	let type = typ.toLowerCase();
	let types = ['used', 'ratelimit'];
	if (type !== types.find(type)) {
		return 'Invalid Type';
	}
	const channel = await client.channels.fetch(ch);
	let usr = await client.users.fetch(user)
	let ty = type
		.replace('used', endpoint + ' Has been Used by Someone.')
		.replace('ratelimit', 'Someone Got Rate Limited. L');

	let newRequest = new MessageEmbed()
		.setTitle('Endpoint ' + type)
		.setColor('99C2FF')
		.addField('Endpoint', endpoint.toUpperCase())
		.addField('Used BY:', "Someone")
		.setThumbnail(
			'https://cdn.discordapp.com/avatars/789440075364433931/5cec48456c63846f909f05bd52332e01.png'
		);

	const { logger } = require('./config.js');
	const webhookClient = new Discord.WebhookClient(logger.id, logger.token);

	webhookClient.send('', {
		username: 'API',
		embeds: [embed]
	});
};
