const fetech = require(`node-fetch`);
const config = require(`./config`)
const TOKEN = "NzY1NTc4NTI1ODE4MDkzNjA4.X4W2kA.qNAMkUmbNMjCrXXDa38BsabT7z8";
async function getBotGuilds() {
    const fetech = require(`node-fetch`);
    const response = await fetech(`https://discord.com/api/v6/users/@me/guilds
`, {
    method: 'GET',
    headers: {
        Authorization: `Bot ${TOKEN}`
    }
});
return response.json();
}
module.exports = ( getBotGuilds );
